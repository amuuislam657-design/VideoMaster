package com.videomaster.app.converter

import android.media.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer

/**
 * Extracts and decodes the audio track from any Android-supported video file (.mp4, .webm, .mkv)
 * using native Android MediaExtractor and MediaCodec pipelines.
 */
object AudioExtractor {

    suspend fun extractAudioTrack(
        videoFilePath: String,
        outputAudioFile: File,
        onProgress: (Float) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(videoFilePath)
            var audioTrackIndex = -1

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    break
                }
            }

            if (audioTrackIndex == -1) {
                return@withContext Result.failure(Exception("No valid audio track detected in video source."))
            }

            extractor.selectTrack(audioTrackIndex)
            val trackFormat = extractor.getTrackFormat(audioTrackIndex)
            val durationUs = trackFormat.getLong(MediaFormat.KEY_DURATION)

            // Setup MediaMuxer to write audio track
            val muxer = MediaMuxer(outputAudioFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxerAudioTrack = muxer.addTrack(trackFormat)
            muxer.start()

            val maxBufferSize = 256 * 1024
            val buffer = ByteBuffer.allocate(maxBufferSize)
            val bufferInfo = MediaCodec.BufferInfo()

            while (true) {
                bufferInfo.offset = 0
                bufferInfo.size = extractor.readSampleData(buffer, 0)
                if (bufferInfo.size < 0) {
                    bufferInfo.size = 0
                    break
                } else {
                    bufferInfo.presentationTimeUs = extractor.sampleTime
                    bufferInfo.flags = extractor.sampleFlags
                    muxer.writeSampleData(muxerAudioTrack, buffer, bufferInfo)
                    
                    if (durationUs > 0) {
                        val progress = (bufferInfo.presentationTimeUs.toFloat() / durationUs.toFloat()).coerceIn(0f, 1f)
                        onProgress(progress)
                    }
                    extractor.advance()
                }
            }

            muxer.stop()
            muxer.release()
            extractor.release()

            Result.success(outputAudioFile)
        } catch (e: Exception) {
            extractor.release()
            Result.failure(e)
        }
    }
}
