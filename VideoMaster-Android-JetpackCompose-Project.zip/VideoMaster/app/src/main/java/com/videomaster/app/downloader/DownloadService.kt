package com.videomaster.app.downloader

import android.app.*
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.InputStream
import java.io.OutputStream

class DownloadService : Service() {
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private val client = OkHttpClient()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val downloadUrl = intent?.getStringExtra("DOWNLOAD_URL") ?: return START_NOT_STICKY
        val fileName = intent.getStringExtra("FILE_NAME") ?: "video.mp4"

        createNotificationChannel()
        val notification = createNotification("Starting download...", 0)
        startForeground(NOTIFICATION_ID, notification)

        scope.launch {
            try {
                executeDownload(downloadUrl, fileName)
            } catch (e: Exception) {
                updateNotification("Download failed: ${e.localizedMessage}", 0, true)
            } finally {
                stopForeground(STOP_FOREGROUND_DETACH)
                stopSelf()
            }
        }

        return START_NOT_STICKY
    }

    private fun executeDownload(url: String, fileName: String) {
        val request = Request.Builder().url(url).build()
        val response = client.newCall(request).execute()

        if (!response.isSuccessful) throw Exception("HTTP ${response.code}")

        val body = response.body ?: throw Exception("Empty response body")
        val totalBytes = body.contentLength()
        val inputStream: InputStream = body.byteStream()

        // Insert into Android MediaStore Downloads directory
        val resolver = contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VideoMaster")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }

        val uri: Uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
            ?: throw Exception("Failed to create MediaStore entry")

        val outputStream: OutputStream = resolver.openOutputStream(uri)
            ?: throw Exception("Failed to open output stream")

        val buffer = ByteArray(8 * 1024)
        var bytesRead: Int
        var totalRead: Long = 0
        var lastUpdate = System.currentTimeMillis()

        outputStream.use { out ->
            inputStream.use { inp ->
                while (inp.read(buffer).also { bytesRead = it } != -1) {
                    out.write(buffer, 0, bytesRead)
                    totalRead += bytesRead

                    val now = System.currentTimeMillis()
                    if (now - lastUpdate > 500 && totalBytes > 0) {
                        val progress = ((totalRead * 100) / totalBytes).toInt()
                        updateNotification("Downloading ${fileName} (${progress}%)", progress, false)
                        lastUpdate = now
                    }
                }
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            contentValues.clear()
            contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, contentValues, null, null)
        }

        updateNotification("Download completed! Saved to Downloads/VideoMaster", 100, true)
    }

    private fun createNotification(message: String, progress: Int): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VideoMaster Downloader")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setProgress(100, progress, progress == 0)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(message: String, progress: Int, completed: Boolean) {
        val notificationManager = getSystemService(NotificationManager::class.java)
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("VideoMaster Downloader")
            .setContentText(message)
            .setSmallIcon(if (completed) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_sys_download)
            .setProgress(100, progress, false)
            .setOngoing(!completed)
            .build()
        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "VideoMaster Downloads",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    companion object {
        const val CHANNEL_ID = "videomaster_downloads_channel"
        const val NOTIFICATION_ID = 1001
    }
}
