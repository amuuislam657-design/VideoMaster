package com.videomaster.app.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Black & Purple Dark Palette
val DarkBlack = Color(0xFF080511)
val SurfaceDark = Color(0xFF140C26)
val SurfaceCard = Color(0xFF1E1438)
val SurfaceElevated = Color(0xFF2A1C4E)

val PrimaryPurple = Color(0xFF8B5CF6)
val AccentViolet = Color(0xFFA855F7)
val GlowPurple = Color(0xFFC084FC)
val DarkPurple = Color(0xFF6D28D9)

val TextPrimary = Color(0xFFF3F4F6)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)

val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)
