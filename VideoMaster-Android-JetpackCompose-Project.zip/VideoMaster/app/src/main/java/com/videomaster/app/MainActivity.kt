package com.videomaster.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.google.android.gms.ads.MobileAds
import com.videomaster.app.ads.AdMobBanner
import com.videomaster.app.ui.navigation.VideoMasterBottomNav
import com.videomaster.app.ui.screens.*
import com.videomaster.app.ui.theme.DarkBlack
import com.videomaster.app.ui.theme.VideoMasterTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize Google Mobile Ads SDK for AdMob banner & interstitials
        MobileAds.initialize(this) {}

        setContent {
            VideoMasterTheme {
                var currentTab by remember { mutableStateOf("home") }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(DarkBlack),
                    bottomBar = {
                        Column {
                            // AdMob Banner above bottom navigation
                            AdMobBanner()
                            VideoMasterBottomNav(
                                currentTab = currentTab,
                                onTabSelected = { currentTab = it }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            "home" -> HomeScreen(
                                onNavigateToPlayer = { currentTab = "player" },
                                onNavigateToExtractor = { currentTab = "extractor" }
                            )
                            "extractor" -> AudioExtractorScreen(
                                onNavigateToPlayer = { currentTab = "player" }
                            )
                            "player" -> PlayerScreen()
                            "history" -> HistoryScreen(
                                onPlayItem = { currentTab = "player" }
                            )
                            "settings" -> SettingsScreen()
                        }
                    }
                }
            }
        }
    }
}
