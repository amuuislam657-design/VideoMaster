package com.videomaster.app.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/**
 * Manages interstitial full-screen ads triggered when completing a download or audio conversion.
 */
class AdMobInterstitialManager(private val context: Context) {
    private var interstitialAd: InterstitialAd? = null

    init {
        loadAd()
    }

    fun loadAd() {
        val adRequest = AdRequest.Builder().build()
        // Official Google Sample Interstitial Ad Unit ID
        InterstitialAd.load(
            context,
            "ca-app-pub-3940256099942544/1033173712",
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                }
            }
        )
    }

    fun showAd(activity: Activity, onDismissed: () -> Unit) {
        if (interstitialAd != null) {
            interstitialAd?.show(activity)
            interstitialAd = null
            loadAd() // Preload next ad
            onDismissed()
        } else {
            onDismissed()
        }
    }
}
