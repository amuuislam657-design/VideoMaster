# VideoMaster - Modern Android Video Downloader & Audio Extractor

Built with **Kotlin**, **Jetpack Compose**, **Android Media3 (ExoPlayer)**, **OkHttp**, and **Google AdMob**.

## Features Included
1. **Paste video URL** & instant link analysis.
2. **Multi-resolution detector** (4K 2160p, 1080p FHD, 720p HD, 480p, 360p, MP3 Audio).
3. **Download legally accessible videos** in their original available quality with live progress notifications.
4. **Native Audio Extractor**: Extracts and converts video audio tracks to MP3 using Android MediaExtractor and MediaCodec.
5. **Built-in Player**: Powered by AndroidX Media3 ExoPlayer with gesture scrubbing and speed controls.
6. **Download History**: Tracks all completed media with local storage management.
7. **Google AdMob Integration Structure**:
   - Adaptive Banner at the bottom of the screen.
   - Interstitial ad manager triggered upon download/conversion completion.
   - Pre-configured with official Google AdMob test IDs (`ca-app-pub-3940256099942544/6300978111`).
8. **Dark Black & Purple Gradient Theme**: Designed with Material 3 for OLED efficiency and modern aesthetics.

## How to Open in Android Studio (Beginner Guide)
1. Download this project archive and unzip it on your computer.
2. Open **Android Studio** (Ladybug or newer recommended).
3. Click **Open** and select the unzipped `VideoMaster` folder.
4. Android Studio will automatically run Gradle Sync to download libraries.
5. Connect your Android phone via USB (with Developer Mode & USB Debugging enabled) or start an Android Emulator.
6. Click the green **Run (▶)** button!

## Production Deployment Checklist
- Replace the sample AdMob Application ID in `AndroidManifest.xml` with your live Google AdMob App ID.
- Replace banner unit ID (`6300978111`) and interstitial unit ID (`1033173712`) with your production IDs.
- Generate your release keystore via `Build > Generate Signed Bundle / APK`.
